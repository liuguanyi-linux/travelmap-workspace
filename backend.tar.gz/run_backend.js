
require('ts-node/register');
require('tsconfig-paths/register');
require('./src/main');
