import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, Search, MapPin, Building2, ChevronUp, ChevronDown } from 'lucide-react';
import * as Icons from 'lucide-react';
import { motion, AnimatePresence, useAnimation, PanInfo, useDragControls } from 'framer-motion';
import { useLanguage } from '../../contexts/LanguageContext';
import { useData } from '../../contexts/DataContext';
import { useFavorites } from '../../hooks/useFavorites';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-hot-toast';

interface CityDrawerProps {
  isVisible: boolean;
  onSelectCategory: (category: string) => void;
  onSelectCity: (city: { name: string, center: [number, number], zoom: number }) => void;
  searchResults: any[]; // Pass search results to display in list
  onPoiClick: (poi: any) => void;
  onClose?: () => void;
  onSearch?: (keyword: string, category?: string) => void;
  activeCityName?: string;
}

// Level 1: Cities
// Level 2: Categories (Attractions, Hotels, Food) for selected city
// Level 3: POI List for selected category
type ViewLevel = 'cities' | 'categories' | 'list';

import { City } from '../../types/data';

const CategoryIcon = React.memo(({ icon, name, size = 22, className = "" }: { icon: string, name: string, size?: number, className?: string }) => {
  if (icon && (icon.startsWith('http') || icon.startsWith('/') || icon.startsWith('data:'))) {
      return (
          <img 
              src={icon} 
              alt={name} 
              style={{ width: size, height: size }} 
              className={`object-contain ${className}`} 
          />
      );
  }
  
  const IconComponent = (Icons as any)[icon] || Icons.MapPin;
  return <IconComponent size={size} className={className} />;
});

export default function CityDrawer({ isVisible, onSelectCategory, onSelectCity, searchResults, onPoiClick, onClose, onSearch, activeCityName }: CityDrawerProps) {
  // State for view mode: 'city_selection' or 'category_list'
  const [viewMode, setViewMode] = useState<'city_selection' | 'category_list'>('category_list'); // Default to list since FilterBar handles city selection
  
  const controls = useAnimation();
  const dragControls = useDragControls();
  const [selectedCity, setSelectedCity] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [searchKeyword, setSearchKeyword] = useState('');
  const { t, language } = useLanguage();
  const { cities = [], spotCategories = [], refreshData } = useData();
  const { isFavorite, toggleFavorite } = useFavorites();
  const { user } = useAuth();

  const getCityDisplayName = (city: City | undefined) => {
    if (!city) return '';
    // Temporary hardcode for Qingdao translation
    if (city.name === '青岛' && language === 'ko-KR') return '칭다오';
    if (city.name === '青岛' && language === 'ja-JP') return 'チンタオ';
    if (city.name === '青岛' && language === 'en-US') return 'Qingdao';
    
    // We will add i18n support for cities later if needed
    return city.name;
  };

  const getCityDisplayNameByName = (cityName: string) => {
      const city = cities.find(c => c.name === cityName);
      
      // Temporary hardcode for Qingdao translation fallback
      if (!city && cityName === '青岛') {
          if (language === 'ko-KR') return '칭다오';
          if (language === 'ja-JP') return 'チンタオ';
          if (language === 'en-US') return 'Qingdao';
      }
      
      return city ? getCityDisplayName(city) : cityName;
  };

  // Reset view and position when drawer closes/opens
  useEffect(() => {
    if (isVisible) {
      controls.start({ y: 0 });
      // FORCE city selection mode every time the drawer is opened via tab
      // This overrides any previous state to ensure "click city tab -> see city list"
      setViewMode('city_selection');
      // If a city is technically "active" in the background, we might want to clear it or keep it
      // But the view MUST be selection.
      
      // Reset height to initial
      setDrawerMode('initial');
    } else {
      // Force hide when not visible
      controls.start({ y: '100%' });
    }
  }, [isVisible, controls]); // Removed selectedCity/activeCityName dependencies to prevent auto-switching back

  const handleCityClick = (city: City) => {
      // Logic handled by FilterBar in parent, but kept for internal consistency if needed
      if (!city || !city.name) return;
      
      setSelectedCity(city.name);
      onSelectCity({ name: city.name, center: [city.lng || 0, city.lat || 0], zoom: city.zoom || 13 });
      
      setViewMode('category_list');
      setSelectedCategory('spot');
      onSelectCategory('spot');
      
      controls.start({ y: 0 });
  };

  const handleBackToCitySelection = () => {
      setViewMode('city_selection');
      // Optional: Clear selection or keep it? 
      // If user wants to select another city, maybe clear active city?
      // But keeping map context is usually better.
      // Let's just switch view.
  };
  
  const handleCategoryClick = (category: string) => {
    if (selectedCategory === category) {
        // Optional: toggle off? Usually we keep at least one category selected or allow deselection.
        // For now, let's allow re-selection to just ensure it's active.
        return;
    }
    setSelectedCategory(category);
    setSearchKeyword('');
    onSelectCategory(category);
  };

  const handleDragEnd = (event: any, info: PanInfo) => {
    const { offset, velocity } = info;
    const isDraggingDown = offset.y > 0;
    const isFast = Math.abs(velocity.y) > 500;

    if (isDraggingDown) {
        if (drawerMode === 'full') {
            if (offset.y > 100 || isFast) {
                setDrawerMode('initial');
            } else {
                controls.start({ y: 0 });
            }
        } else {
            // At initial height, drag down closes drawer OR goes back to cities?
            // If in category_list mode, dragging down at peek height could go back to cities?
            // Or just close/minimize. 
            // Let's stick to minimizing or snapping back.
            // Closing is handled by parent activeTab usually.
            // If we want to support "drag to close", we need an onClose prop that clears activeTab.
            // But activeTab='city' keeps it open.
            // So we just snap back for now.
            controls.start({ y: 'calc(100% - 180px)' }); // Snap to peek
        }
    } else {
        // Dragging up
        if (drawerMode === 'initial') {
            if (offset.y < -50 || Math.abs(velocity.y) > 300) {
                setDrawerMode('full');
            } else {
                // Snap back to peek
                // handled by variants
            }
        } else {
            controls.start({ y: 0 });
        }
    }
  };

  const [drawerMode, setDrawerMode] = useState<'initial' | 'full'>('initial');

  useEffect(() => {
      // When switching views, reset to initial height
      setDrawerMode('initial');
  }, [viewMode]);

  // Header area (drag handle + close + back button/title): ~50px
  // Categories area: ~40px
  // Card area: ~80px
  // Total visible needed: ~170px + safe area padding
  // Increasing to 240px to definitely show the first card fully.
  
  const drawerVariants: any = {
      hidden: { y: '100%' },
      visible: { 
          y: drawerMode === 'initial'
              ? 'calc(100% - 200px)' 
              : 0,
          transition: { type: 'spring', damping: 25, stiffness: 200 }
      }
  };

  // ... (keep categories generation logic, but move it inside component or use memo)
  // Ensure categories filter logic is robust
   const categories = (spotCategories || [])
     .filter(cat => cat && cat.key && cat.name) 
     .filter(cat => !['transport', 'airport', 'high_speed_rail', 'high-speed-rail', 'train'].includes(cat.key))
     .sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0))
     .map(cat => {
       const translationKey = `categories.${cat.key}`;
       const translatedLabel = t(translationKey);
       const label = translatedLabel !== translationKey ? translatedLabel : cat.name;
       return {
         id: cat.key,
         label: label,
         iconName: cat.icon,
         color: cat.key === 'spot' ? 'text-green-600 bg-green-50' :
                cat.key === 'accommodation' ? 'text-blue-600 bg-blue-50' :
                cat.key === 'dining' ? 'text-orange-600 bg-orange-50' :
                cat.key === 'shopping' ? 'text-cyan-600 bg-cyan-50' : // 颜色改为亮青色 (Cyan)
                cat.key === 'golf' ? 'text-emerald-600 bg-emerald-50' :
                'text-gray-600 bg-gray-50'
       };
     });
   
   const finalCategories = categories.filter(c => 
       !['high_speed_rail', 'airport', 'high-speed-rail', 'train', 'station'].includes(c.id) &&
       !c.label.includes('高铁') && 
       !c.label.includes('High Speed Rail')
   );
   
   const hasTransport = finalCategories.some(c => c.id === 'transport');
   
   if (!hasTransport) {
     finalCategories.push({
         id: 'transport',
         label: t('categories.transport') !== 'categories.transport' ? t('categories.transport') : '交通',
         iconName: 'Train',
         color: 'text-indigo-600 bg-indigo-50'
     });
   }

   // Ensure cities is an array and filter invalid entries
   const cityList = (Array.isArray(cities) ? cities : [])
     .filter(city => city && city.name);

   const [loadingError, setLoadingError] = useState(false);

   useEffect(() => {
     if (isVisible && cityList.length === 0) {
         const timer = setTimeout(() => {
             if (cityList.length === 0) {
                 setLoadingError(true);
                 refreshData();
             }
         }, 2000);
         return () => clearTimeout(timer);
     } else {
         setLoadingError(false);
     }
   }, [isVisible, cityList.length, refreshData]);

   useEffect(() => {
     // Removed refreshData() on visible to prevent redundant fetches
     // Data is already loaded by DataContext on mount
   }, [isVisible]);

  // Sync with activeCityName prop
  const lastSyncedCityRef = React.useRef<string>('');
  useEffect(() => {
      if (isVisible && activeCityName) {
          // Update internal selection if it differs, but NEVER auto-switch view mode
          // This ensures the drawer always stays in the mode the user left it in (or forced to 'city_selection' by the open effect)
          if (activeCityName !== selectedCity) {
             setSelectedCity(activeCityName);
             // Do NOT switch to category_list here. User wants to see the grid first.
             // If we want to auto-select a default category, we can do it, but keep viewMode as is.
             if (!selectedCategory) {
                 setSelectedCategory('spot');
             }
          }
          lastSyncedCityRef.current = activeCityName;
      }
  }, [isVisible, activeCityName]);

  return (
    <AnimatePresence mode="wait">
      {isVisible && (
        <motion.div
          initial="hidden"
          animate="visible"
          exit="hidden"
          variants={drawerVariants}
          drag="y"
          dragControls={dragControls}
          dragListener={false}
          dragConstraints={{ top: 0, bottom: 0 }} 
          dragElastic={0.2}
          onDragEnd={handleDragEnd}
          className="fixed bottom-0 left-0 right-0 z-[60] bg-slate-50/95 dark:bg-gray-900/95 backdrop-blur-lg rounded-t-3xl shadow-[0_-10px_60px_rgba(0,0,0,0.15)] border-t border-gray-200 dark:border-gray-800 overflow-hidden flex flex-col will-change-transform"
          style={{ 
              height: '66vh', 
              maxHeight: '66vh'
          }}
        >
          {/* Drag Handle (Click to Toggle) */}
          <div 
            className="w-full flex justify-center pt-3 pb-2 cursor-pointer z-10 shrink-0 hover:bg-black/5 dark:hover:bg-white/5 transition-colors touch-none items-center gap-2" 
            onPointerDown={(e) => dragControls.start(e)}
            onClick={() => setDrawerMode(prev => prev === 'initial' ? 'full' : 'initial')}
          >
            {drawerMode === 'full' ? (
                <ChevronDown className="text-gray-500 dark:text-gray-400" size={24} />
            ) : (
                <ChevronUp className="text-gray-500 dark:text-gray-400" size={24} />
            )}
            <span className="text-xs text-gray-400 font-medium tracking-wide">{t('clickToToggle')}</span>
          </div>

          {/* Close Button */}
          <div className="absolute top-2 right-4 z-[120] pointer-events-auto">
            <button 
                onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault(); 
                    console.log('[CityDrawer] Close clicked');
                    // Directly call onClose if provided, it should clear the active tab
                    if (onClose) {
                        onClose();
                    }
                }}
                className="p-1.5 bg-black/5 dark:bg-white/10 rounded-full text-gray-500 dark:text-gray-400 hover:bg-black/10 dark:hover:bg-white/20 transition-colors"
            >
                <X size={16} />
            </button>
          </div>

          {/* Header with Back Button (Only in Category List mode) */}
          {viewMode === 'category_list' && (
              <div 
                className="px-4 pb-0 flex items-center gap-1 shrink-0 touch-none z-[110] relative min-h-[28px]"
                onPointerDown={(e) => dragControls.start(e)}
              >
                  <button 
                    onClick={handleBackToCitySelection}
                    onPointerDown={(e) => e.stopPropagation()}
                    className="p-0.5 -ml-1 rounded-full hover:bg-black/5 dark:hover:bg-white/5 active:bg-black/10 dark:active:bg-white/10 transition-colors"
                  >
                      <ChevronLeft size={24} className="text-gray-600 dark:text-gray-300" />
                  </button>
                  <span className="text-lg font-bold text-gray-800 dark:text-white">
                      {getCityDisplayNameByName(selectedCity || activeCityName || '')}
                  </span>
              </div>
          )}
          
          {/* Content Area */}
          <div 
            className={`flex-1 overflow-y-auto overflow-x-hidden px-4 ${viewMode === 'category_list' ? 'pb-24' : 'pb-12'}`}
            style={{ 
                overscrollBehavior: 'contain', 
                touchAction: 'pan-y',
                WebkitOverflowScrolling: 'touch',
                paddingBottom: (viewMode === 'category_list' && drawerMode === 'initial') 
                    ? 'calc(96vh - 400px + 6rem)' 
                    : undefined
            }}
            onPointerDown={(e) => e.stopPropagation()}
            onTouchStart={(e) => e.stopPropagation()}
          >
            
            {/* View Mode 1: City Selection */}
            {viewMode === 'city_selection' && (
                <div className="pt-1 pb-1">
                    {/* Title removed for compactness */}
                    
                    {cityList.length === 0 ? (
                        <div className="flex flex-col items-center justify-center py-4 text-gray-500">
                            {loadingError ? (
                                <>
                                    <p className="mb-2">{t('cityDrawer.loadingError')}</p>
                                    <button 
                                        onClick={() => refreshData()}
                                        className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm"
                                    >
                                        {t('cityDrawer.retry')}
                                    </button>
                                </>
                            ) : (
                                <p>{t('cityDrawer.loading')}</p>
                            )}
                        </div>
                    ) : (
                        <div className="grid grid-cols-4 gap-3 px-1">
                            {cityList.map((city, index) => (
                                <button
                                    key={city.name || index}
                                    onClick={() => handleCityClick(city)}
                                    className="flex flex-col items-center justify-center p-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 shadow-sm active:scale-95 transition-transform min-w-[70px] w-auto min-h-[64px]"
                                >
                                    <div className="p-0.5 rounded-full bg-gray-50 dark:bg-gray-700 mb-1 text-gray-400 dark:text-gray-300">
                                        <Building2 size={16} />
                                    </div>
                                    <span className="font-bold text-gray-800 dark:text-white text-[12px] z-10 text-center leading-tight w-full break-words whitespace-normal">{getCityDisplayName(city)}</span>
                                </button>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* View Mode 2: Category List */}
            {viewMode === 'category_list' && (
                <div className="space-y-2 pt-0.5 pb-0">
                    {/* Category Grid */}
                    <div className="flex overflow-x-auto gap-2 px-1 pb-1 snap-x snap-mandatory scrollbar-hide -mx-1">
                        {finalCategories.map((cat) => {
                            const isSelected = selectedCategory === cat.id;
                            return (
                                <button
                                    key={cat.id}
                                    onClick={() => handleCategoryClick(cat.id)}
                                    className={`flex-none flex items-center justify-center px-3 py-1.5 rounded-md transition-all duration-200 h-auto w-auto snap-center ${
                                        isSelected 
                                            ? 'bg-blue-50 dark:bg-blue-900/30 border-2 border-blue-500 shadow-sm' 
                                            : 'bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border border-gray-100 dark:border-gray-700 shadow-sm active:scale-95'
                                    }`}
                                >
                                    <span className={`font-bold text-sm z-10 text-center leading-tight whitespace-nowrap ${
                                        isSelected ? 'text-blue-600 dark:text-blue-400' : 'text-gray-800 dark:text-white'
                                    }`}>
                                        {cat.label}
                                    </span>
                                </button>
                            );
                        })}
                    </div>

                    {/* Inline List */}
                    {selectedCategory && (
                        <div className="space-y-2 pt-0.5 animate-in fade-in slide-in-from-bottom-4 duration-300">
                            {/* List Content */}
                            {(() => {
                                const filteredResults = (searchResults || []).filter(item => {
                                    if (!item) return false;
                                    // 过滤掉已下架的项
                                    if (item.isActive === false) return false;
                                    
                                    const hasTag = (tag: string) => {
                                        if (item.tags && Array.isArray(item.tags)) {
                                            return item.tags.includes(tag);
                                        }
                                        if (item.type && typeof item.type === 'string') {
                                            return item.type.includes(tag);
                                        }
                                        return false;
                                    };

                                    if (selectedCategory === 'transport') {
                                        return hasTag('transport') || hasTag('high_speed_rail') || hasTag('airport') || hasTag('train') || hasTag('station') || hasTag('rail') || hasTag('metro') || hasTag('bus') || hasTag('subway');
                                    }
                                    
                                    if (selectedCategory === 'spot') {
                                        return hasTag('spot') || hasTag('attraction');
                                    }

                                    if (selectedCategory === 'attraction') {
                                        return hasTag('spot') || hasTag('attraction');
                                    }

                                    return hasTag(selectedCategory);
                                });

                                if (filteredResults.length === 0) {
                                    return (
                                        <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                                            <Search size={48} className="mb-4 opacity-20" />
                                            <p>{t('cityDrawer.noResults')}</p>
                                        </div>
                                    );
                                }

                                return filteredResults.map((spot, index) => {
                                    const isFav = isFavorite(spot.id);
                                    
                                    return (
                                    <div 
                                        key={spot.id}
                                        onClick={() => onPoiClick(spot)}
                                        className="bg-white dark:bg-gray-800 rounded-xl p-2 shadow-sm border border-gray-100 dark:border-gray-700 flex gap-2 active:scale-[0.99] transition-transform cursor-pointer relative"
                                    >
                                        {/* Index Badge */}
                                        <div className="absolute -left-1 -top-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs font-bold shadow-sm z-20">
                                            {index + 1}
                                        </div>

                                        <button 
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                if (!user) {
                                                    toast('로그인 후 즐겨찾기 가능합니다.', {
                                                        icon: '⚠️',
                                                        style: {
                                                            borderRadius: '10px',
                                                            background: '#333',
                                                            color: '#fff',
                                                        },
                                                    });
                                                    return;
                                                }
                                                toggleFavorite({
                                                    id: spot.id,
                                                    name: spot.name,
                                                    type: spot.type || 'spot',
                                                    address: spot.address,
                                                    location: spot.location,
                                                    imageUrl: spot.photos?.[0]?.url || `https://picsum.photos/seed/${spot.id}/300/200`
                                                });
                                                if (isFav) {
                                                    toast.success('즐겨찾기에서 제거되었습니다.', {
                                                        style: {
                                                            borderRadius: '10px',
                                                            background: '#333',
                                                            color: '#fff',
                                                        },
                                                    });
                                                } else {
                                                    toast.success('즐겨찾기에 추가되었습니다.', {
                                                        style: {
                                                            borderRadius: '10px',
                                                            background: '#333',
                                                            color: '#fff',
                                                        },
                                                    });
                                                }
                                            }}
                                            className="absolute top-2 right-2 p-1 bg-white/80 dark:bg-black/20 backdrop-blur-sm rounded-full hover:bg-red-50 transition-colors z-10"
                                        >
                                            <Icons.Heart size={14} className={isFav ? "text-red-500 fill-red-500" : "text-gray-400"} />
                                        </button>

                                        <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-lg overflow-hidden shrink-0">
                                            {spot.photos?.[0] ? (
                                                <img 
                                                    src={spot.photos[0].url} 
                                                    alt={spot.name} 
                                                    className="w-full h-full object-cover" 
                                                    loading="lazy"
                                                    decoding="async"
                                                    width={64}
                                                    height={64}
                                                />
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center text-gray-400">
                                                    <MapPin size={20} />
                                                </div>
                                            )}
                                        </div>
                                        <div className="flex-1 min-w-0 flex flex-col justify-center py-0">
                                            <div>
                                                <h3 className="font-bold text-gray-900 dark:text-white truncate text-lg mb-0.5 pr-6">{spot.name}</h3>
                                                {/* <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1 leading-relaxed mb-0.5">{spot.address || t('cityDrawer.noAddress')}</p> */}
                                                {spot.intro && <div className="text-xs text-gray-400 dark:text-gray-500 line-clamp-2 leading-tight" dangerouslySetInnerHTML={{ __html: spot.intro }} />}
                                            </div>
                                        </div>
                                    </div>
                                )});
                            })()}
                        </div>
                    )}
                </div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function SearchIcon() {
    return (
        <svg
            className="w-12 h-12 text-gray-300"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
        >
            <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={1.5}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
        </svg>
    );
}
