-- AlterTable
ALTER TABLE "Spot" ADD COLUMN "intro" TEXT;
