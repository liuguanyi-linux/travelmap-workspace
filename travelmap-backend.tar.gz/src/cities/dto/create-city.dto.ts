export class CreateCityDto {
  name: string;
  lng: number;
  lat: number;
  zoom?: number;
}
