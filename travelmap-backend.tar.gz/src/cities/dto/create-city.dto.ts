export class CreateCityDto {
  name: string;
  nameEn?: string;
  nameKo?: string;
  lng: number;
  lat: number;
  zoom?: number;
}
